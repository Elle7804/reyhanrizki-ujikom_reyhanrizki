<?php
$koneksi = mysqli_connect("localhost", "root", "", "reyhan_appem_kel2");


?>